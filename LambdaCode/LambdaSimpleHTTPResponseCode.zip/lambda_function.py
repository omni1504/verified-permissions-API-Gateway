import json

print('Loading function')


def lambda_handler(event, context):
    
    # Creating a simple response
    response = {
        "statusCode": 200,
        "body": f"Hello! AuthC and AuthZ successful. This is a simple response from Lambda."
    }
    
    return response
