# USES PORTIONS OF CODE FROM https://github.com/cyberark/identity-aws-verified-permissions-demo/blob/main/LICENSE.md 
import os, urllib
import json
import boto3
import logging
from jose import jwk, jwt
from jose.utils import base64url_decode
from typing import Dict, List
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import time

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

AWS_REGION = os.environ['AWS_REGION']
COGNITO_USER_POOL_ID = os.environ['COGNITO_USER_POOL_ID']
#COGNITO_APP_CLIENT_ID = os.environ['COGNITO_APP_CLIENT_ID']
POLICY_STORE_ID = os.environ['POLICY_STORE_ID']

keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(AWS_REGION, COGNITO_USER_POOL_ID)
# instead of re-downloading the public keys every time
# we download them only on cold start
# https://aws.amazon.com/blogs/compute/container-reuse-in-lambda/
with urllib.request.urlopen(keys_url) as f:
    response = f.read()
keys = json.loads(response.decode('utf-8'))['keys']

avp_client = boto3.client('verifiedpermissions')
# Initialize Cognito client
cognito_client = boto3.client('cognito-idp')

def lambda_handler(event, context):
    logger.debug(f'Debugging. Event is:  {event}')
    # Check if authorization token is present in the request
    if 'authorizationToken' not in event:
        logger.info('No authorization token in the event')
        return generate_policy('Unauthorized', event['methodArn'])

    token = event['authorizationToken'].replace('Bearer', '').strip()
    # Perform verification of the token, for example, using a database lookup or an external API call
    
    if not validate_token(token):
        return generate_policy('Unauthorized', event['methodArn'])
    
    claims = jwt.get_unverified_claims(token)
    # Extract token information
    user_id = claims['sub']
    # Extracting the method ARN
    method_arn = event['methodArn']
    # Assuming your API Gateway method ARN looks like:
    # arn:aws:execute-api:region:account_id:api_id/stage/method/verb/resource_path
    # Extracting the resource and stage from method ARN
    arn_parts = method_arn.split(':')
    api_gateway_arn_parts = arn_parts[5].split('/')
    aws_account_id = arn_parts[4]
    region = arn_parts[3]
    stage = api_gateway_arn_parts[1]
    rest_api_id = api_gateway_arn_parts[0]
    http_method = api_gateway_arn_parts[2]
    resource = '/'.join(api_gateway_arn_parts[3:])
    logger.debug(f'Region is: {region}, http_method is {http_method}, resource is {resource}')
    
    # Get User attributes only if scope does NOT contain m2m
    
    if not "m2m" in claims['scope']:
        user_attributes = get_user_attributes(token=token, user_id=user_id)
    else:
        user_attributes = {}
    
    # Call Amazon Verified Permissions to authorize. The return value is Allow / Deny and can be assigned to the IAM Policy
    effect = check_authorization(principal_id=claims['sub'], action=http_method, resource=resource, claims=claims,
                                 user_attributes=user_attributes)

    # Generate a policy
    policy = generate_policy(effect, method_arn)
    
    return policy
    
    
def validate_token(token):
    # get the kid from the headers prior to verification
    headers = jwt.get_unverified_headers(token)
    kid = headers['kid']

    # search for the kid in the downloaded public keys
    key_index = -1
    for i in range(len(keys)):
        if kid == keys[i]['kid']:
            key_index = i
            break

    if key_index == -1:
        logger.info('Public key not found in jwks.json')
        return False

    # construct the public key
    public_key = jwk.construct(keys[key_index])
    


    # get the last two sections of the token,
    # message and signature (encoded in base64)
    message, encoded_signature = str(token).rsplit('.', 1)

    # decode the signature
    decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))
    
    # verify the signature
    if not public_key.verify(message.encode("utf8"), decoded_signature):
        logger.info('Signature verification failed')
        return False

    logger.info('Signature successfully verified')

    # since we passed the verification, we can now safely
    # use the unverified claims
    claims = jwt.get_unverified_claims(token)

    # additionally we can verify the token expiration
    if time.time() > claims['exp']:
        logger.info('Token is expired')
        return False

    # Commenting this out - VerifiedPermissions would check this
    # and the Audience  (use claims['client_id'] if verifying an access token)
    #if claims['client_id'] != COGNITO_APP_CLIENT_ID:
    #    logger.info('Token was not issued for this audience')
    #    return False

    # now we can use the claims
    logger.info(claims)
    return claims


def generate_policy(effect, resource):
    # Generate IAM policy with the specified effect ("Allow" or "Deny") and the resource
    policy = {
        'principalId': 'user',  # Assuming a user-based authentication system
        'policyDocument': {
            'Version': '2012-10-17',
            'Statement': [{
                'Action': 'execute-api:Invoke',
                'Effect': effect,
                'Resource': resource
            }]
        }
    }
    return policy


def check_authorization(principal_id: str, action: str, resource: str, claims: Dict, user_attributes: Dict) -> str:
    principal = Identifier(entityType='User', entityId=principal_id)
    action = {'actionType': 'Action', 'actionId': action}
    logger.debug(f'Debugging. Resource is: {resource}')
    resource = Identifier(entityType='Resource', entityId=resource)
    entities = {'entityList': _get_data_entities(token_claims=claims, user_attributes=user_attributes)}
    context = {
        'contextMap': {
            'client_id': {
                'string': claims['client_id']
            },
        }
    }

    logger.info(
        f'store id:{POLICY_STORE_ID}, principal:{asdict(principal)}, action:{action}, resource:{asdict(resource)}, context:{context}, entities:{entities}'
    )
    authz_response = avp_client.is_authorized(
        policyStoreId=POLICY_STORE_ID,
        principal=asdict(principal),
        resource=asdict(resource),
        action=action,
        context=context,
        entities=entities,
    )

    return authz_response['decision']

@dataclass
class Identifier:
    entityId: str
    entityType: str

# Example how to use entities - not used currently
def _get_data_entities(token_claims: Dict, user_attributes: Dict = None) -> List:
    data_entities: List[Dict] = []
    
    # Example below if using pre-auth Lambda, you can use below to add info from a tokem
    # add info from token
    #if token_claims['user_roles']:
    #    for role in token_claims['user_roles']:
    #        data_entities.append({'identifier': asdict(Identifier(entityType='UserGroup', entityId=role))})

    # add user and role parents
    user_entity = {'identifier': asdict(Identifier(entityType='User', entityId=token_claims['sub'])), 'parents': []}
    
    logger.debug(f"Token claims are: {token_claims}")
    
    # Adding Scope to the list of attributes (MUST be present)
    user_attributes_dict = {}
    if 'scope' in token_claims:
        user_attributes_dict["scope"] = {'string': token_claims['scope']}
    if user_attributes:
        for attribute in user_attributes:
            # Dirty hack to split custom:<> attribute into separate one, only leaving second part
            if attribute == "custom:adgroups":
                attribute_without_custom = attribute.split(':')
                user_attributes_dict[attribute_without_custom[1]] = {'string': user_attributes[attribute]}
            else:
                user_attributes_dict[attribute] = {'string': user_attributes[attribute]}
    user_entity['attributes'] = user_attributes_dict

    #for role in token_claims['user_roles']:
    #    user_entity['parents'].append(asdict(Identifier(entityType='UserGroup', entityId=role)))
    data_entities.append(user_entity)
    return data_entities

    
def get_user_attributes(token: str, user_id: str) -> Dict:
    try:
        # Call GetUserInfo to retrieve user attributes
        response = cognito_client.get_user(
            AccessToken=token
        )
        # Extract user attributes from the response
        user_attributes = {attr['Name']: attr['Value'] for attr in response['UserAttributes']}
        logger.info(f"User attributes retrieved: {user_attributes}")
        return user_attributes
    except cognito_client.exceptions.NotAuthorizedException:
        logger.info("User is not authorized to perform this action.")
    except cognito_client.exceptions.InvalidParameterException:
        logger.info("The provided access token is invalid.")
    except Exception as e:
        logger.info(f"An error occurred while retrieving user attributes: {e}")
        return None